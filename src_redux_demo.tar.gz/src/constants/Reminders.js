export const Add_Reminder="add_new_reminder";
export const DELETE_REMINDER="delete_reminder";

export default Add_Reminder;