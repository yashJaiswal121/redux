import React from 'react';
import ReactDOM from 'react-dom';
import FormComponent from './components/FormComponent';
import {Provider} from 'react-redux';
import {createStore} from 'redux';
import masterReducer from './reducers/reducer1';
const store=createStore(masterReducer);
ReactDOM.render(
<Provider store={store}>
<FormComponent/>
</Provider>
, document.getElementById('root'));

